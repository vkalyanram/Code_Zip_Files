import unittest
import datetime	
from dateutil.relativedelta import *
import re
from Support import Support as s
class TestSupportMethods(unittest.TestCase):

	def test_change_date_format(self):
		self.assertEqual(s.change_date_format('2022-30-12'),'12-30-2022')

	def test_date_validation(self):
		self.assertEqual(s.date_validation('07-19-2022'),False)
		self.assertEqual(s.date_validation('12-02-2022'),True)    

	def test_remainder_date(self):
		date=s.date_format('22-02-2022')
		self.assertEqual(s.remainder_date(date,3),'12-05-2022')
		self.assertEqual(s.remainder_date(date,1),'12-03-2022') 

	def test_get_command_value(self):
		self.assertEqual(s.get_command_value('ADD_SUBSCRIPTION MUSIC FREE'),['ADD_SUBSCRIPTION', 'MUSIC', 'FREE'])	      
		self.assertEqual(s.get_command_value('ADD_TOPUP TEN_DEVICE 2'),['ADD_TOPUP', 'TEN_DEVICE', '2'])	      
	
	def test_date_format(self):
		self.assertEqual(s.date_format('30-12-2022'),datetime.datetime(2022, 12, 30, 0, 0))
		self.assertEqual(s.date_format('24-05-1996'),datetime.datetime(1996, 5, 24, 0, 0))	

	def test_date_validation_error(self):
		self.assertEqual(s.date_validation_error(),None)

	def test_subscription_validation_error(self):
		self.assertEqual(s.subscription_validation_error(),None)
	
	def test_renewal_validation_error(self):
		self.assertEqual(s.renewal_validation_error(),None)

	def test_date_validation_error(self):
		self.assertEqual(s.date_validation_error(),None)

	def test_topup_validation_error(self):
		self.assertEqual(s.topup_validation_error(),None)
		
	def test_subscription_duplicate_error(self):
		self.assertEqual(s.subscription_duplicate_error(),None)
		
	def test_topup_duplicate_error(self):
		self.assertEqual(s.topup_duplicate_error(),None)						

			
if __name__ == '__main__':
	unittest.main()
