import unittest
from Support import Support as s
from Plan import Plan as p
from Subscription import Subscription as subscription_class

class TestSubscriptionMethods(unittest.TestCase):

	def test_subscription_remainder(self):
		object_for_process_input=subscription_class('24-05-2022')
		self.assertEqual(object_for_process_input.subscription_remainder('MUSIC','PERSONAL'),'14-06-2022')
		self.assertEqual(object_for_process_input.subscription_remainder('PODCAST','PREMIUM'),'14-08-2022')
		self.assertEqual(object_for_process_input.subscription_remainder('VIDEO','FREE'),'14-06-2022')

	def test_add_plan(self):
		object_for_process_input=subscription_class('24-05-2022')	
		self.assertEqual(object_for_process_input.add_plan(('MUSIC','PERSONAL')),None)
		self.assertEqual(object_for_process_input.add_plan(('VIDEO','PERSONAL')),None)
	
	def test_add_topup(self):
		object_for_process_input=subscription_class('24-05-2022')	
		self.assertEqual(object_for_process_input.add_topup(('FOUR_DEVICE','3')),None)

	def test_get_price(self):
		object_for_process_input=subscription_class('24-05-2022')
		self.assertEqual(subscription_class.get_price(('MUSIC','PERSONAL')),100)
		self.assertEqual(subscription_class.get_price(('PODCAST','PREMIUM')),300)
		self.assertEqual(subscription_class.get_price(('VIDEO','FREE')),0)

	def test_get_topup_price(self):
		object_for_process_input=subscription_class('24-05-2022')
		self.assertEqual(subscription_class.get_topup_price(('FOUR_DEVICE','3')),150)
		self.assertEqual(subscription_class.get_topup_price(('TEN_DEVICE','2')),200)

	def test_renewal(self):
		object_for_process_input=subscription_class('24-05-2022')
		object_for_process_input.add_plan(('MUSIC','PERSONAL'))	
		object_for_process_input.add_topup(('FOUR_DEVICE','3'))
		self.assertEqual(object_for_process_input.renewal(),None)
	
	def test_remainder_date_output(self):
		object_for_process_input=subscription_class('24-05-2022')	
		self.assertEqual(object_for_process_input.remainder_date_output(),['RENEWAL_REMINDER MUSIC 14-06-2022', 'RENEWAL_REMINDER VIDEO 14-06-2022'])	