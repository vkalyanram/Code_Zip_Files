Candidate Notes
===============

This is a place for you to give us notes on your solution.

Add any information needed to build, run or test your solution here.
