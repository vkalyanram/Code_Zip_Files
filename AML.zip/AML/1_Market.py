class Market:
    def __init__(self, owned):
        self.owned = owned
        self.total=100
        self.shares=[]
        self.owner=None
        
    def diff_print(self):
        Result=""
        #print("Company Name      :    ",self.owned)
        #print("Total Share value :    ",self.total)
        #print("No of shares      :    ",len(self.shares))
        
        share_value=0
        #print("shares:")
        if self.shares:
                for i in self.shares:
                    Result=Result+" "+self.owned
                    #print("Share Name ",i.owned+"\t",end="") 
                    #print()
                    #print("Share Value ",str(i.total)+"\t",end="")
                    #print()  
                    Result=Result+" "+i.owned+" "+str(i.percentage)+"\n"
                    share_value+=i.total

        #print("Total Shares Values:",share_value)
        #print()
        d=int(self.total-share_value)
        Output=" "+self.owned+" "+"?"+" "+str(d)+"\n"
        Result=Output+Result
        print(Result)
                    

        #print()
                             

    def share_(self,owning,percentage):
            owning.owner=self
            owning.percentage=percentage
            owning.total=self.total*percentage/100
            self.shares.append(owning)
   
    
m=Market("a")
b=Market("b")
c=Market("c")
m.share_(b,25)
m.share_(c,70)
m.diff_print()



