from Support import Support as support_object
from Plan import Plan as plan_object
class Subscription():
	
	subscription_date:str
	subscription_date_validation=False
	subscription_plans=[]
	topup_plans=[]
	output_total_susubscription=[]
	output_remainder=[]
	
	def __init__(self,subscription_date):
		self.subscription_date=support_object.change_date_format(subscription_date)
		Subscription.subscription_date_validation=True
		
	def subscription_remainder(self,plan_name,categary_name):
		date=support_object.date_format(self.subscription_date)
		months=plan_object.plans.get(plan_name.capitalize()).get(categary_name).get('subscription')
		return support_object.remainder_date(date,months)

	def add_plan(self,var:tuple):
		validation_list_for_subscription_duplicate=list(map(lambda x:x[0],self.subscription_plans))
		if var[0] not in validation_list_for_subscription_duplicate:
			 self.subscription_plans.append(var)
		else:
		   support_object.subscription_duplicate_error()     
		

	def add_topup(self,var:tuple):
		if self.subscription_plans:
			if len(self.topup_plans)==0:
				self.topup_plans.append(var)
			else:
				support_object.topup_duplicate_error()    
		 

	def get_price(var:tuple):
		return plan_object.plans.get((var[0]).capitalize()).get(var[1]).get("subscription_price")

	def get_topup_price(var:tuple):
		return (plan_object.topup.get(var[0]).get('Cost_per_month'))*int(var[1])	    

	def renewal(self):
		[self.output_total_susubscription.append(Subscription.get_price(i)) for i in self.subscription_plans]
		if self.topup_plans:
			self.output_total_susubscription.append(Subscription.get_topup_price(self.topup_plans[0]))
		renewal_total="RENEWAL_AMOUNT"+" "+str(sum(self.output_total_susubscription))
		
		output=[]
		output.extend(self.remainder_date_output())
		output.append(renewal_total)	
		print("\n".join(output))

	def remainder_date_output(self):
		[self.output_remainder.append("RENEWAL_REMINDER"+" "+each_plan[0]+" "+self.subscription_remainder(each_plan[0],each_plan[1])) for each_plan in self.subscription_plans]	
		return self.output_remainder


		
	

			 
	
