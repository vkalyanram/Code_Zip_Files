class Plan():
	months=[x for x in range(4)]
	price=[x*100 for x in months[:3]]
	no_of_dev=[4,10]
	plans={

	'Music':{
		'FREE':{'subscription':months[1],'subscription_price':price[0] },
		'PERSONAL':{'subscription':months[1],'subscription_price':price[1] },
		'PREMIUM':{'subscription':months[3],'subscription_price':price[2]+price[1]//2 }
		},	
	'Video':{
		'FREE':{'subscription' :months[1],'subscription_price' :price[0] },
		'PERSONAL':{'subscription':months[1],'subscription_price':price[2] },
		'PREMIUM':{'subscription':months[3],'subscription_price':price[1]*(months[2]+months[3]) }
		},	
	   
	'Podcast':{
		'FREE':{'subscription':months[1],'subscription_price':price[0] },
		'PERSONAL':{'subscription':months[1],'subscription_price':price[1] },
		'PREMIUM':{'subscription':months[3],'subscription_price':price[1]*months[3]}
		}	
	}	

	topup={
		'FOUR_DEVICE':{'Max_no_Devices':no_of_dev[0],'Cost_per_month':price[1]//2},
		'TEN_DEVICE':{'Max_no_Devices':no_of_dev[1],'Cost_per_month':price[1]}
		}
	   