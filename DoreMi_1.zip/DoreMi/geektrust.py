from sys import argv
from Support import Support as support_object
from Subscription import Subscription as subscription_object

def main():
  
  if len(argv) != 2:
      raise Exception("File path not entered")
  file_path = argv[1]
  f = open(file_path, 'r')

  Lines = f.readlines()
  for line in Lines:
      query=support_object.get_command_value(line.strip())

      if query[0]=='START_SUBSCRIPTION':
     
          if support_object.date_validation(query[1]):  
              object_for_process_input=subscription_object(query[1])
          else:
              support_object.date_validation_error()  

      if query[0]=='ADD_SUBSCRIPTION':

          if subscription_object.subscription_date_validation:
              object_for_process_input.add_plan((query[1],query[2]))
          else:
              support_object.subscription_validation_error()

      if query[0]=='ADD_TOPUP':

          if subscription_object.subscription_date_validation:

              if object_for_process_input .subscription_plans:
                  object_for_process_input.add_topup((query[1],query[2]))    
              else:
                  support_object.topup_validation_error()
          else:
              support_object.add_topup_date_validation_error()

      if query[0]=='PRINT_RENEWAL_DETAILS':

          if subscription_object.subscription_date_validation:

              if object_for_process_input.subscription_plans:
                  object_for_process_input.renewal()
              else:
                  support_object.renewal_validation_error()
          else:
              support_object.renewal_validation_error()      
      
if __name__ == "__main__":
  main()