import datetime	
from dateutil.relativedelta import *
import re
class Support():

	def change_date_format(date):	
		formated_date=str(date).split(" ")[0]
		return re.sub(r'(\d{4})-(\d{1,2})-(\d{1,2})', '\\3-\\2-\\1', formated_date)
		
	def date_format(date):
		temp=date.split("-")
		return datetime. datetime(int(temp[2]),int(temp[1]),int(temp[0]))

	def date_validation(date):
		format = "%d-%m-%Y"
		try:
			validation_flag = bool(datetime.datetime.strptime(date,format))
		except ValueError:
			validation_flag=False
		return validation_flag

	def remainder_date(date,months):
		no_of_days=10
		no_of_months=months
		end_date=date+relativedelta(months=+no_of_months)
		remainder_date=Support.change_date_format(end_date- datetime. timedelta(days=no_of_days))
		return remainder_date

	def get_command_value(command):	
		return command.split(' ')

	def date_validation_error():
		print("INVALID_DATE")	

	def add_subscription_date_validation_error():
		print("ADD_SUBSCRIPTION_FAILED INVALID_DATE")

	def add_topup_date_validation_error():
		print("ADD_TOPUP_FAILED INVALID_DATE")



	def renewal_validation_error():
		print("SUBSCRIPTIONS_NOT_FOUND")
		
	def topup_validation_error():
		print("ADD_TOPUP_FAILED SUBSCRIPTIONS_NOT_FOUND")



	def subscription_duplicate_error():
		print("ADD_SUBSCRIPTION_FAILED DUPLICATE_CATEGORY")
 
	def topup_duplicate_error():
		print("ADD_TOPUP_FAILED DUPLICATE_TOPUP")	

	
		

