from Support import Support as support_object
from Plan import Plan as plan_object
class Subscription():
	subscription_plans=[]
	topup_plans=[]
	output_total_susubscription=[]
	output_remainder=[]
	
			
	def add_plan(self,var:tuple):

		validation_list_for_subscription_duplicate=list(map(lambda x:x[0],self.subscription_plans))

		if var[0] not in validation_list_for_subscription_duplicate:
			 self.subscription_plans.append(var)
		else:
		   support_object.subscription_duplicate_error()     

	def add_topup(self,var:tuple):

		if self.subscription_plans:

			if len(self.topup_plans)==0:
				self.topup_plans.append(var)
			else:
				support_object.topup_duplicate_error() 

		else:
			support_object.topup_validation_error()		

	def renewal(self,object_variable):
		[self.output_total_susubscription.append(object_variable.plan_database(i).get('price')) for i in self.subscription_plans]
		
		if self.topup_plans:
		    topup_total=self.get_topup_price(self.topup_plans[0],object_variable)
		    self.output_total_susubscription.append(topup_total)
		
		renewal_total="RENEWAL_AMOUNT"+" "+str(sum(self.output_total_susubscription))
		
		output=[]
		output.extend(self.remainder_date_output(object_variable))
		output.append(renewal_total)	
		
		print("\n".join(output))

	def remainder_date_output(self,object_variable):
		for i in self.subscription_plans:
			date=support_object.date_format(str(object_variable))
			months=object_variable.plan_database(i).get('subscription')
			remainder_date=support_object.remainder_date(date,months)
			self.output_remainder.append("RENEWAL_REMINDER"+" "+i[0]+" "+str(remainder_date))	
		return self.output_remainder

	def get_topup_price(self,var:tuple,object_variable):
		no_of_months=int(var[1])
		price= int(object_variable.plan_database(('TOPUP',var[0])).get('price'))  	
		return no_of_months*price

	