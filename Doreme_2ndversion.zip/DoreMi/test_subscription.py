import unittest
from Support import Support
from Plan import Plan
from Subscription import Subscription as subscription_class

class TestSubscriptionMethods(unittest.TestCase):

	def test_add_plan(self):
		object_variable=Plan('24-05-2022')
		object_for_process_input=subscription_class()	
		self.assertEqual(object_for_process_input.add_plan(('MUSIC','PERSONAL')),None)
		self.assertEqual(object_for_process_input.add_plan(('MUSIC','FREE')),None)
		self.assertEqual(object_for_process_input.add_plan(('VIDEO','PERSONAL')),None)
	
	def test_add_topup(self):
		object_variable=Plan('24-05-2022')
		object_for_process_input=subscription_class()	
		self.assertEqual(object_for_process_input.add_topup(('FOUR_DEVICE','3')),None)

	def test_renewal(self):
		object_variable=Plan('24-05-2022')
		object_for_process_input=subscription_class()
		object_for_process_input.add_plan(('MUSIC','PERSONAL'))	
		object_for_process_input.add_topup(('FOUR_DEVICE','3'))
		self.assertEqual(object_for_process_input.renewal(object_variable),None)
	
	def test_remainder_date_output(self):
		object_variable=Plan('24-05-2022')
		object_for_process_input=subscription_class()
		object_for_process_input.add_plan(('MUSIC','PERSONAL'))	
		object_for_process_input.add_topup(('FOUR_DEVICE','3'))
		self.assertEqual(object_for_process_input.remainder_date_output(object_variable),['RENEWAL_REMINDER MUSIC 14-06-2022', 'RENEWAL_REMINDER VIDEO 14-06-2022'])
	
	def test_get_topup_price(self):
		object_variable=Plan('24-05-2022')
		object_for_process_input=subscription_class()	
		self.assertEqual(object_for_process_input.get_topup_price(('FOUR_DEVICE','3'),object_variable),150)
		self.assertEqual(object_for_process_input.get_topup_price(('TEN_DEVICE','3'),object_variable),300)
		self.assertEqual(object_for_process_input.get_topup_price(('FOUR_DEVICE','5'),object_variable),250)
