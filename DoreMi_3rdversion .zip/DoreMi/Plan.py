from dataclasses import dataclass
from Support import Support as support_object

@dataclass
class Plan():

	subscription_date:str

	@staticmethod
	def plan_database(var:tuple):
		
		months=[x for x in range(4)]
		price=[x*100 for x in months[:3]]
		no_of_dev=[4,10]
		plans={

		'MUSIC':{
		'FREE':{'subscription':months[1],'price':price[0] },
		'PERSONAL':{'subscription':months[1],'price':price[1] },
		'PREMIUM':{'subscription':months[3],'price':price[2]+price[1]//2 }
		 },	
		'VIDEO':{
		'FREE':{'subscription' :months[1],'price' :price[0] },
		'PERSONAL':{'subscription':months[1],'price':price[2] },
		'PREMIUM':{'subscription':months[3],'price':price[1]*(months[2]+months[3]) }
		 },	
	   
		'PODCAST':{
		'FREE':{'subscription':months[1],'price':price[0] },
		'PERSONAL':{'subscription':months[1],'price':price[1] },
		'PREMIUM':{'subscription':months[3],'price':price[1]*months[3]}
		},	
		'TOPUP':{
		'FOUR_DEVICE':{'Max_no_Devices':no_of_dev[0],'price':price[1]//2},
		'TEN_DEVICE':{'Max_no_Devices':no_of_dev[1],'price':price[1]}
		}
		}

		return plans.get(var[0]).get(var[1])

	def __str__(self):
		return self.subscription_date
	   
