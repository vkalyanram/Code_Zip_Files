import unittest
from Plan import Plan
class TestPlanMethods(unittest.TestCase):

    def test__str__(self):  
        p=Plan('30-01-2022')
        self.assertEqual(p.__str__(),'30-01-2022')
        self.assertEqual(p,Plan(subscription_date='30-01-2022'),{'Max_no_Devices': 4, 'price': 50})       

    def test_plan_database(self):
        p=Plan('30-01-2022')
        self.assertEqual(Plan.plan_database(('MUSIC','FREE')),{'subscription': 1, 'price': 0})
        self.assertEqual(Plan.plan_database(('MUSIC','PREMIUM')),{'price': 250, 'subscription': 3})
        self.assertEqual(Plan.plan_database(('VIDEO','PERSONAL')),{'price': 200, 'subscription': 1})
        self.assertEqual(Plan.plan_database(('PODCAST','PREMIUM')),{'price': 300, 'subscription': 3})
        self.assertEqual(p.plan_database(('TOPUP','FOUR_DEVICE')),{'Max_no_Devices': 4, 'price': 50})    
        
if __name__ == '__main__':
    unittest.main()
